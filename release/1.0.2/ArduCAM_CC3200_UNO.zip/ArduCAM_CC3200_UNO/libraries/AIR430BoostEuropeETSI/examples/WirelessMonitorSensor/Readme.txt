To add more sensors to a network, change the ADDRESS_LOCAL definition.
Be sure to give each node in the network a unique address. Do not use
0 as it is the broadcast address.